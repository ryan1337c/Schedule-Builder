package General;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Resources extends JPanel implements ActionListener{
	
	private JLabel troll = new JLabel();
	private ImageIcon huh = new ImageIcon("Resources/trollFace.png");
	private JButton back;
	
	public Resources () {
		setLayout(null);
		setSize(Main.WIDTH, Main.HEIGHT);
		//setPreferredSize(new Dimension(Main.WIDTH, Main.HEIGHT));
		troll.setIcon(huh);
		troll.setBounds(0,0,Main.WIDTH, Main.HEIGHT);
		troll.setVerticalAlignment(JLabel.CENTER);
		troll.setHorizontalAlignment(JLabel.CENTER);
		
		// back button
		back = new JButton("Back");
		back.addActionListener(this);
		back.setBounds(0, 0, 100, 20);
		
		add(back);
		add(troll);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back)
			Main.cl.show(Main.layer, "1");
	}
}
