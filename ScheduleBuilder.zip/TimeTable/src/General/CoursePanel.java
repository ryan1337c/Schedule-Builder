package General;

import java.awt.Color;


import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class CoursePanel extends JPanel implements ActionListener{
	// table stuff
	private int[][] table = new int[22][7]; // used to draw time table
	private int blockW, blockH;
	private String[] times = {"8:00 - 8:30", "8:30 - 9:00", "9:00 - 9:30", "9:30 - 10:00", "10:00 - 10:30", "10:30 - 11:00", "11:00 - 11:30", "11:30 - 12:00",
			"12:00 - 12:30", "12:30 - 13:00", "13:00 - 13:30", "13:30 - 14:00", "14:00 - 14:30", "14:30 - 15:00", "15:00 - 15:30", "15:30 - 16:00", "16:00 - 16:30",
			"16:30 - 17:00", "17:00 - 17:30", "17:30 - 18:00", "18:00 - 18:30", "18:30 - 19:00"};
	private int[] timeInt = {800, 830, 900, 930, 1000, 1030, 1100, 1130, 1200, 1230, 1300, 1330, 1400, 1430, 1500, 1530, 1600, 1630, 1700, 1730, 1800, 1830, 1900};
	// stores index of each time which will be used to calculate location for user input
	private HashMap<Integer, Integer> timeIndex = new HashMap<>();
	private HashMap<Integer, Boolean> timeAvailable = new HashMap<>();
	private HashMap<String, HashMap<Integer, Boolean>> timeSlotsDay = new HashMap<>();
	private List<JLabel> taskLabels = new ArrayList<JLabel>();
	private List<String> taskDay = new ArrayList<String>();
	private List<Integer> taskStart = new ArrayList<Integer>();
	private List<Integer> taskEnd = new ArrayList<Integer>();
	
	// days of the week + time
	private String[] days = {"Time", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
	private HashMap<String, Integer> daysIndex = new HashMap<>();

	// fonts
	private Font fontTime, fontHead;
	
	// general stuff
	private JButton button_sel;
	private JTextField search, search2, search3;
	private JLabel enTime, enCourse, enDay, enDel;
	private int start, end;
	private int increment;
	
	// options
	private JRadioButton halfHour;
	private JRadioButton hour;
	private ButtonGroup group;
	private JButton back;
	
	// colors
	private int max = 255;
	private int min = 200;
	
	public CoursePanel() {
		// panel properties
		setLayout(null);
		setSize(JFrame.MAXIMIZED_HORIZ, JFrame.MAXIMIZED_VERT);
		
		// style
		fontTime = new Font("Arial", Font.PLAIN, 16);
		fontHead = new Font("Arial", Font.BOLD, 20);
		
		// size
		blockW = 150;
		blockH = 30;
		
		// user input task UI
		search = new JTextField();
		search.setBounds(Main.WIDTH / 2 - 100, Main.HEIGHT + 100, 250, 30);
		
		button_sel = new JButton("Select");
		button_sel.addActionListener(this);
		button_sel.setBounds(search.getX() + (search.getWidth()/3), search.getY() + 90, 100, search.getHeight());
		
		// user input time UI
		search2 = new JTextField();
		search2.setBounds(Main.WIDTH / 2 - 100, Main.HEIGHT + 150, 250, 30);
		
		enCourse = new JLabel("Enter Task");
		enCourse.setFont(fontTime);
		enCourse.setBounds(search.getX() - 100, search.getY(), 100, search.getHeight());
		add(enCourse);
		add(button_sel);
		add(search);
		
		enTime = new JLabel("Enter Time");
		enTime.setFont(fontTime);
		enTime.setBounds(search.getX() - 100, search.getY() + 50, 100, search.getHeight());
		add(enTime);
		add(search2);
		
		// user input day UI
		search3 = new JTextField();
		search3.setBounds(Main.WIDTH / 2 + 300, Main.HEIGHT + 100, 250, 30);
		enDay = new JLabel("Enter Day");
		enDay.setFont(fontTime);
		enDay.setBounds(search.getX() + 300, search.getY(), 100, search.getHeight());
		add(enDay);
		add(search3);
		
		// user input delete item UI
		enDel = new JLabel("Delete");
		
		// fills time index
		for (int i = 0; i < timeInt.length; i++) {
			timeIndex.put(timeInt[i], i);
			timeAvailable.put(timeInt[i], true);
		}
		
		// fills days index and sets up time slots for each day of the week
		for (int i = 0; i < days.length - 1; i++) {
			daysIndex.put(days[i + 1], i);
			HashMap<Integer, Boolean> timeSlots = new HashMap<>();
			timeSlots.putAll(timeAvailable);
			timeSlotsDay.put(days[i+1], timeSlots);
		}
		
		
		// radio buttons 
		halfHour = new JRadioButton("30 mins");
		hour = new JRadioButton("60 mins");
		
		halfHour.addActionListener(this);
		hour.addActionListener(this);
		
		halfHour.setBounds(search.getX() + search.getWidth() / 5, search.getY() + 30, 100, 20);
		hour.setBounds(search.getX() +search.getWidth() / 5 + 100, search.getY() + 30, 150, 20);
		
		group = new ButtonGroup(); 
		group.add(halfHour);
		group.add(hour);
		add(halfHour);
		add(hour);
		
		// back button
		back = new JButton("Back");
		back.addActionListener(this);
		back.setBounds(0, 0, 100, 20);
		add(back);
	}

	public void paint(Graphics g) {
		super.paint(g); // cancel the overriding method and invoking paint() in super class
		Graphics g2D = (Graphics2D) g;
		
		// time headings
		g2D.setFont(fontTime);
		for (int r = 0; r < table.length; r++ ) {
			// times
			g2D.drawRect(Main.WIDTH / 4 - blockW, Main.HEIGHT / 6 + r * blockH, blockW, blockH);
			g2D.drawString(times[r], Main.WIDTH / 4 - blockW + 10, Main.HEIGHT / 6 + r * blockH + blockH);
		}
		
		// day headings
		for (int i = 0; i < table[0].length + 1; i++) {
			JLabel label = new JLabel();
			label.setBounds(blockW * i + Main.WIDTH / 4 - blockW, Main.HEIGHT / 6 - 2 * blockH, blockW,
					blockH * 2);
			label.setText(days[i]);
			label.setFont(fontHead);
			label.setHorizontalAlignment(JLabel.CENTER);
			label.setVerticalAlignment(JLabel.CENTER);
			add(label);
			g2D.drawRect(blockW * i + Main.WIDTH / 4 - blockW, Main.HEIGHT / 6 - 2 * blockH, blockW, blockH * 2);
			
			// makes it so text is viewable without having to resize
			validate();
			repaint();
		}
		
		g2D.setFont(fontHead);
		
		// table
		for (int r = 0; r < table.length; ++r) {
			for (int c = 0; c < table[0].length; ++c) {
				g2D.drawRect(blockW * c + Main.WIDTH / 4, blockH * r + Main.HEIGHT / 6, blockW, blockH);
			}
		}
	}
	public void setBlockWidth(int w) {
		blockW = w;
	}

	public void setBlockHEight(int h) {
		blockH = h;
	}

	public int getBlockWidth() {
		return blockW;
	}

	public int getBlockHeight() {
		return blockH;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == back) 
			Main.cl.show(Main.layer, "1");
		if (e.getSource() == halfHour) 
			increment = 30;
			
		if (e.getSource() == hour) 
			increment = 100;
		
		if (e.getSource() == button_sel) {
			// proceeds only if all inputs are given by user
			if (!search.getText().equals("") && search2.getText().length() >= 3 && search2.getText().length() <= 4
					&& daysIndex.containsKey(search3.getText()) && increment != 0) {
				try {
					String day = search3.getText();
					start = Integer.parseInt(search2.getText());
					
					// ensures time frame matches the 24 hour clock (military time)
					int t1 = (start + increment) / 10;
					t1 %= 10;
					if (t1 >= 6)
						end = start + 70;
					else
						end = start + increment;

					// checks if time input is correct and available on the schedule
					if (timeIndex.containsKey(start) && timeIndex.containsKey(end) && timeSlotsDay.get(day).get(start) == true
							&& timeSlotsDay.get(day).get(end) == true) {
						drawRectangle(daysIndex.get(day), timeIndex.get(start), blockW,
								blockH * (timeIndex.get(end) - timeIndex.get(start)), search.getText(), day);
						// update timeSlot
						updateAvailability(start, end - 30, false, day);
					}
				}
				catch (Exception s) {
					s.printStackTrace();
				}
			}
		}		
	}
	
	public void drawRectangle(int xPos, int yPos, int width, int height, String task, String day) {
		// generate random light colors
		int r = (int)(Math.random()*(max-min-1))+min;
		int g = (int)(Math.random()*(max-min-1))+min;
		int b = (int)(Math.random()*(max-min-1))+min;
		
		// fill time
		JLabel rect = new JLabel(task);
		rect.setOpaque(true);
		rect.setBackground(new Color(r, g, b));
		rect.setHorizontalAlignment(JLabel.CENTER);
		rect.setVerticalAlignment(JLabel.TOP);
		rect.setBounds(blockW * xPos + Main.WIDTH / 4, blockH * yPos + Main.HEIGHT / 6, width, height);
		
		rect.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				onMouseClicked(e);
			}
		});
		
		add(rect);
		
		// needed to potentially locate and delete task 
		taskLabels.add(rect);
		taskDay.add(day);
		taskStart.add(start);
		taskEnd.add(end - 30);
		
		// invokes layout manager for the component to ensure it instantly appears
		revalidate();
		repaint();
	}
	/*
	 * Detects which task label was clicked and deletes it
	 */
	private void onMouseClicked(MouseEvent e) {
		for (int i = 0; i < taskLabels.size(); i++) {
			if (e.getSource() == taskLabels.get(i)) {
				remove(taskLabels.remove(i));
				updateAvailability(taskStart.get(i), taskEnd.get(i), true, taskDay.get(i));
				taskStart.remove(i);
				taskEnd.remove(i);
				taskDay.remove(i);
				break;
			}
		}
		// invokes layout manager for the component to ensure it instantly deletes
		revalidate();
		repaint();
	}
	
	/*
	 * Updates time slots according to if task were added/deleted
	 */
	private void updateAvailability (int start, int end, boolean isTimeFree, String day) {
		timeSlotsDay.get(day).put(start, isTimeFree);
		timeSlotsDay.get(day).put(end, isTimeFree);
	}

}


