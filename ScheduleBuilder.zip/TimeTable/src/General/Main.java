package General;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Stack;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
public class Main extends JFrame implements MouseListener{
	
	public static final int WIDTH = 1600;
	public static final int HEIGHT = 700;
	private Resources rsc;
	private CoursePanel tasks;
	private JLabel pic1, pic2;
	public static CardLayout cl = new CardLayout();
	public static JPanel layer = new JPanel();
	private JPanel home = new JPanel();
	
	private Main() {
		// Title
		JLabel title = new JLabel();
		title.setText("Course Time Table");
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setVerticalAlignment(JLabel.TOP);
		title.setFont(new Font("Times New Roman", Font.PLAIN, 50));
		title.setBounds(new Rectangle(100, 100));

		JPanel titlePanel = new JPanel();
		titlePanel.setBounds(WIDTH / 2 - 200, 0, 400, 60);

		titlePanel.add(title);

		Border border = BorderFactory.createLineBorder(Color.black, 3);

		// Schedule Section
		pic1 = new JLabel();
		ImageIcon schedule = new ImageIcon("Resources/schedule.PNG");
		pic1.setIcon(schedule);
		pic1.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		pic1.setText("See Time Table");
		pic1.setHorizontalTextPosition(JLabel.CENTER);
		pic1.setVerticalTextPosition(JLabel.TOP);
		pic1.setBorder(border);

		JPanel imagePanel1 = new JPanel();
		imagePanel1.setBounds(WIDTH / 2 - 600, HEIGHT / 2 - 200, pic1.getIcon().getIconWidth() + 20,
				pic1.getIcon().getIconHeight() + 40);
		imagePanel1.add(pic1);

		// Resource / Links
		pic2 = new JLabel();
		ImageIcon rscImage = new ImageIcon("Resources/books.PNG");
		pic2.setIcon(rscImage);
		pic2.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		pic2.setText("Resources");
		pic2.setHorizontalTextPosition(JLabel.CENTER);
		pic2.setVerticalTextPosition(JLabel.TOP);
		pic2.setBorder(border);

		JPanel imagePanel2 = new JPanel();
		imagePanel2.setBounds(WIDTH / 2 + 200, HEIGHT / 2 - 200, pic2.getIcon().getIconWidth() + 20,
				pic2.getIcon().getIconHeight() + 40);
		imagePanel2.add(pic2);

		// Mouse input
		pic1.addMouseListener(this);
		pic2.addMouseListener(this);

		// frame
		this.setSize(WIDTH, HEIGHT);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		home.add(titlePanel);
		home.add(imagePanel1);
		home.add(imagePanel2);
		
		// states
		home.setLayout(null);
		tasks = new CoursePanel();
		rsc = new Resources();
		
		// adding states to card layout 
		layer.setLayout(cl);
		layer.add(home, "1");
		layer.add(tasks, "2");
		layer.add(rsc, "3");
		
		// display home state
		cl.show(layer, "1");
		this.add(layer);
		
		// upper icon
		ImageIcon image = new ImageIcon("Resources/YU logo.jpg");
		this.setIconImage(image.getImage());
		
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		new Main();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// switching windows
		if (e.getSource() == pic1) {
			// display time table state
			cl.show(layer, "2");
		}
		if (e.getSource() == pic2) {
			// display resources
			cl.show(layer, "3");
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	

}
